//
//  AOCViewController.h
//  AOC_Wk1
//
//  Created by Nazir Shuqair on 2/5/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AOCViewController : UIViewController{
    
    NSArray *strArray;
    NSMutableString *dynamicString;
    int arrayCount;
    int index;
    UILabel *titleLabel;
    UILabel *authorLabel;
    UILabel *authorNameLabel;
    UILabel *publishedLabel;
    UILabel *publishedDateLabel;
    UILabel *summeryLabel;
    UILabel *bookSummeryLabel;
    UILabel *listOItemsLabel;
    UILabel *listLabel;
}

@end
