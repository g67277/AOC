//
//  AOCAppDelegate.h
//  AOC_Wk1
//
//  Created by Nazir Shuqair on 2/5/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AOCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
