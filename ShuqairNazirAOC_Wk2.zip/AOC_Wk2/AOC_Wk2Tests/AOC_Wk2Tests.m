//
//  AOC_Wk2Tests.m
//  AOC_Wk2Tests
//
//  Created by Nazir Shuqair on 2/10/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface AOC_Wk2Tests : XCTestCase

@end

@implementation AOC_Wk2Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
